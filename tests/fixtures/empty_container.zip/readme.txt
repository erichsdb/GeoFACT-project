kein Geodatenformat in diesem Archiv
